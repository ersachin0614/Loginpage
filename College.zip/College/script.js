// script.js: JavaScript for interactive elements

// Function to handle admission form submission
function submitAdmission(event) {
    event.preventDefault(); // Prevent form from submitting normally
    
    // Example submission logic (add server-side code for handling this data)
    const fullName = document.getElementById("fullName").value;
    const email = document.getElementById("email").value;
    const mobileNumber = document.getElementById("mobileNumber").value;
    const course = document.getElementById("course").value;
    
    // Display an alert upon successful submission
    alert("Admission is successfully done.");
    
    // Redirect to the home page
    window.location.href = "/";
}